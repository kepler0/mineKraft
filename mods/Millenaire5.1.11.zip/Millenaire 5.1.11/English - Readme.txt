==Millénaire installation==

Since Millénaire 5.1.4, the installation procedure has changed. To install it manually, you now need to:
- Install Forge from http://minecraftforge.net/forum/index.php/board,3.0.html
- Move the millenaire-jar, millenaire and millenaire-custom folders inside /mods (create the folder if needed)